<div class="upsell_payment_step_responce_default">
    <section class="warning-banner-section">
     <div class="container"> 
      <div class="row">
       <div class="col-md-7 mx-auto">
           <div class="warning_banner pb-2 px-3 px-md-0">
             <div class="progress mb-3">
                <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="width: 100%"></div>
            </div>
            <h2 class="text-white fw-bold text-center mb-0"> <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>  WAIT  <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
            </h2>
            <div class="warning-content text-center">
                <h2 class="fw-bold text-white text-uppercase"> <?php echo $_SESSION['customer_name']; ?> </h2>
               <h5 class="text-white text-uppercase"> YOUR ORDER IS NOT COMPLETE </h5>
            </div>
           </div>
           <!--text-->
            <div class="add-copy text-center py-3">
                <h4 class="fw-normal"> Your Fusion Smart Watch Order </h4>
                 <h4> 
                    <span class="fw-bold">Qualified You For A</span><br> 
                    <span class="fw-bold"> Dize Case and Security Cord </span>
                </h4>
            </div>
          <!--congrats section-->
          <div class="congrats_block text-center fs-14">
              <p class="mb-0"> <span class="danger-text"> WARNING: </span> There are only </p>
              <p class="mb-0"> <span class="danger-text"> 2 Units </span>  Left in Stock! </p>
              
          </div>
          <!--offer expires-->
           <div class="offer-expires-block text-center py-2">
               <h4 class="fw-bold danger-text expire-offer-text py-3"> Your offer expires in 0:01 </h4>
           </div>
           <!--product inner banner-->
            <div class="product-inner-banner">
                <img src="<?php echo WEBSITEURL; ?>images/bundle-1.gif" class="img-fluid">
            </div>
            <div class="product-description-content my-5">
                <h6 class="pt-3"> About this item  </h6>
                <ul class="p-0">
                    <li> Enjoy music for non-stop 20 Hours with the help of the charging case (earbuds + case). 10mm dynamic driver with composite diaphragm delivers natural sound with high resolution and deep bass.</li>
                    <li> Easy access to music & call controls; Stereo Phone Calls; Stereo & Mono earbud capability; 1-Year Manufacturer Warranty from the Date of Purchase. </li>
                    <li> Ergonomic, lightweight & Touch Control earbuds with BT5.0 chipset ensure quick pairing, seamless connection, 1-step pairing, auto-reconnect and wide compatibility with Bluetooth-enabled smart devices. </li>
                </ul>
                
               <h6 class="pt-3">  Audio Quality </h6>
                <ul class="p-0">
                    <li> Enjoy superior sound quality with Adaptive Equaliser, which automatically tunes music to the shape of your ear for a rich, consistent listening experience.</li>
                    <li> Powerful bass is delivered by a custom-built high-excursion, low-distortion speaker driver.</li>
                    <li> The amplifier powers the speaker driver to remove background noise and works with the H1 chip to control listening levels.</li>
                    <li> A super-efficient high dynamic range amplifier produces pure, incredibly clear sound while also extending battery life.</li>
                </ul>
                <h6 class="pt-3">  Battery </h6>
                    <ul class="p-0">
                        <li> Charge Wirelessly. Use Tirelessly.</li>
                        <li> The Wireless Charging Case delivers more than 24 hours of battery life to keep you and your AirPods Pro on the go. And it’s compatible with Qi-certified chargers. </li>
                        <li> More than 24hr of listening time with multiple additional charges in the case.</li>
                        <li> Up to 4.5 hr of listening time on one charge.</li>
                        <li> Around 1 hr of listening time on only 5 minutes of charging.</li>
                    </ul>
            <h6 class="pt-3">  Comfort </h6>
                <ul class="p-0">
                    <li> Arrival Of The Fittest</li>
                    <li> We refined the details of comfort, creating a new class of in-ear headphones with a customisable fit that forms an exceptional seal for Active Noise Cancellation. You’ll feel your music, not your headphones. </li>
                    <li> Choose from three sizes of soft, flexible silicone tips that click into place.</li>
                    <li> These internally tapered tips conform to your ear shape, keeping AirPods Pro secure. And with vents helping equalise pressure, you feel like there’s nothing in your ears.</li>
                </ul>
                
            </div>
            
       </div>
      </div>
     </div>  
    </section>
        
    <div class="container-fluid px-5 pt-4 checkout-button">
        <div class="row">
         <div class="col-md-12">
             <div class="submit-button__wrapper text-center">
                 <button class="btn text-white buy_upsell_checkout2" data-upsellId="<?php echo $_SESSION['upsellid']; ?>" data-upsell="<?php echo UPSELLID2; ?>"> Complete Checkout  </button>
                 <div class="buy_upsell_checkout2_responce"></div>
             </div>
             <p class="add-small-text text-center mb-2"> JUST ADD $24.99 FOR SHIPPING </p>
              
         </div>
        </div>
    </div>
    <div class="banner-bottom">
       <img src="<?php echo WEBSITEURL; ?>images/pod-banner.jpg" class="img-fluid">
    </div>
</div> 
