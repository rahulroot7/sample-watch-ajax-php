<?php include_once('head.php'); ?>

<style>
    .loader-img {
    
    height: 100vh;
    width: 100%;
    margin: 0 auto;
    position: absolute;

    background: #000000ad;
    z-index: 999;
    display:flex;
    align-items:center;
    justify-content:center;
}

.main-section{
    position:relative;
}

img.loader-responce{
    width:90px;
}
body.loader{
    position:fixed;
    width:100%;
}
</style>
<body class="">
    <!--Loader start-->
    <div class="loader-img" style="display:none;">
        <img class="loader-responce" src="<?php echo WEBSITEURL; ?>images/loading-buffering.gif" alt="loader-img.gif"> 
    </div>
    <!--Loader end-->
   <!--header section-->
   <div class="main-section">
   <header class="text-center py-3">
      <h5 class="text-uppercase text-white fw-normal mb-0"> YOUR FUSION SMART WATCH HAS BEEN RESERVED!  </h5>
   </header>
   <!--logo block-->
   <section class="header-section border-bottom">
      <div class="container">
         <div class="row">
            <div class="col-md-12">
               <div class="logo-block-content text-center py-2">
                  <div class="logo-wrap"> <img src="<?php echo WEBSITEURL; ?>images/logo.png" alt="" class="thk-logo"> </div>
                  <p class="mb-0 pt-1">Watch and Health Monitoring All in One</p>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!--secure checkout section-->
   <section class="secure-checkout-section py-3">
      <div class="container">
         <div class="row">
            <div class="col-md-12">
               <div class="secure-checkout text-center">
                  <p class="py-2 mb-0">Secure Checkout</p>
                  <div class="safecheckout-logo py-3">
                     <img src="<?php echo WEBSITEURL; ?>images/safecheckout-logo-1-line.png" alt="" class="img-fluid">
                  </div>
               </div>
               <div class="breakcrum">
                  <ul class="d-flex list-unstyled justify-content-center mb-0 py-3">
                     <li>Checkout <i class="fa fa-angle-right" aria-hidden="true"></i> </li>
                     <li>Bonuses <i class="fa fa-angle-right" aria-hidden="true"></i></li>
                     <li>Order Receipt</li>
                  </ul>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!--product description section-->
   <section class="product-description-section">
      <div class="container">
         <div class="row">
            <!--left block-->
            <div class="col-md-7">
               <div class="title-wrap border-bottom">
                  <h5 class="title fw-normal">Step 1: <strong>Confirm Your Order</strong> </h5>
               </div>
               <div class="product_descp d-md-flex justify-content-between py-3">
                  <div class="product-image">
                     <img src="<?php echo WEBSITEURL; ?>images/product.png" class="img-fluid" alt="The Dietary Lab Keto">
                  </div>
                  <div class="product-descp-content">
                     <p class="fw-bold"> Fusion Smart Watch </p>
                     <div class="product-list-desc">
                        <table class="fs-15 w-100">
                           <tbody>
                              <tr>
                                 <td><strong>Price:</strong></td>
                                 <td class="color3" align="right">$0.00</td>
                              </tr>
                              <tr>
                                 <td>Shipping &amp; Handling</td>
                                 <td align="right"><span class="ship_price price_total">$9.95</span></td>
                              </tr>
                              <tr>
                                 <td>MasterCard Promo</td>
                                 <td align="right"><span class="ship_price price_total discount">-$4.00</span></td>
                              </tr>
                              <tr class="noborder">
                                 <td>Total</td>
                                 <td align="right">
                                    <div class="full">
                                       <span id="price_total" class="price_total total">$5.95</span>
                                    </div>
                                 </td>
                              </tr>
                           </tbody>
                        </table>
                     </div>
                  </div>
               </div>
               <div class="mastercard-post d-flex p-3 my-4">
                  <div class="master-logo-img"> <img src="<?php echo WEBSITEURL; ?>images/masterCCLogo.png" class="img-fluid" alt="master card logo"> </div>
                  <p class="fs-15 fw-600 mb-0 ps-4"> Good News: Get $4.00 additional discount on shipping when you checkout with Mastercard! </p>
               </div>
               <div class="estimated-ship d-flex p-3 my-4">
                  <div class="poster-logo-img"> <img src="<?php echo WEBSITEURL; ?>images/post.jpg" class="img-fluid" alt="Post logo"> </div>
                  <p class="fs-15 fw-600 mb-0 ps-4"> Your order is estimated to ship by <span> Thursday, December 2, 2021 </span> </p>
               </div>
               <div class="banner_bootom">
                  <img src="<?php echo WEBSITEURL; ?>images/banner-bottom-dk.jpg" alt="" class="img-view img-fluid">
               </div>
            </div>
            <!--right block-->
            <div class="col-md-5 shipping-info-fill">
               <div class="title-wrap border-bottom pt-5 pt-md-0">
                  <h5 class="title fw-normal">Step 2: <strong>Where Do We Ship</strong> </h5>
               </div>
               <form method="POST" action="#" id="order_offer_form">
                  <div id="shipAddress" class="py-3">
                     <div class="mb-3">
                        <input type="text" name="firstname" class="form-control" id="firstname" placeholder="First Name">
                     </div>
                     <div class="mb-3">
                        <input type="text" class="form-control" name="lastname" id="lastname" placeholder="Last Name">
                     </div>
                     <div class="mb-3">
                        <input type="text" class="form-control" name="address" id="address" placeholder="Address">
                     </div>
                     <div class="mb-3">
                        <input type="text" name="address2" class="form-control" placeholder="Apt / Suite #">
                     </div>
                     <div class="mb-3">
                        <input type="tel" class="form-control" name="zip_code" placeholder="Zip / Postal">
                     </div>
                     <div class="mb-3">
                        <input type="text" name="city" class="form-control" placeholder="City">
                     </div>
                     <div class="mb-3">
                        <select id="state" name="state" class="form-control">
                           <option selected="selected">Select State</option>
                           <option value="AL">Alabama</option>
                           <option value="AK">Alaska</option>
                           <option value="AZ">Arizona</option>
                           <option value="AR">Arkansas</option>
                           <option value="AA">Armed Forces Americas</option>
                           <option value="AP">Armed Forces Pacific</option>
                           <option value="AE">Armed Forces Other</option>
                           <option value="CA">California</option>
                           <option value="CO">Colorado</option>
                           <option value="CT">Connecticut</option>
                           <option value="DE">Delaware</option>
                           <option value="DC">District of Columbia</option>
                           <option value="FL">Florida</option>
                           <option value="GA">Georgia</option>
                           <option value="HI">Hawaii</option>
                           <option value="ID">Idaho</option>
                           <option value="IL">Illinois</option>
                           <option value="IN">Indiana</option>
                           <option value="IA">Iowa</option>
                           <option value="KS">Kansas</option>
                           <option value="KY">Kentucky</option>
                           <option value="LA">Louisiana</option>
                           <option value="ME">Maine</option>
                           <option value="MD">Maryland</option>
                           <option value="MA">Massachusetts</option>
                           <option value="MI">Michigan</option>
                           <option value="MN">Minnesota</option>
                           <option value="MS">Mississippi</option>
                           <option value="MO">Missouri</option>
                           <option value="MT">Montana</option>
                           <option value="NE">Nebraska</option>
                           <option value="NV">Nevada</option>
                           <option value="NH">New Hampshire</option>
                           <option value="NJ">New Jersey</option>
                           <option value="NM">New Mexico</option>
                           <option value="NY">New York</option>
                           <option value="NC">North Carolina</option>
                           <option value="ND">North Dakota</option>
                           <option value="OH">Ohio</option>
                           <option value="OK">Oklahoma</option>
                           <option value="OR">Oregon</option>
                           <option value="PA">Pennsylvania</option>
                           <option value="RI">Rhode Island</option>
                           <option value="SC">South Carolina</option>
                           <option value="SD">South Dakota</option>
                           <option value="TN">Tennessee</option>
                           <option value="TX">Texas</option>
                           <option value="UT">Utah</option>
                           <option value="VT">Vermont</option>
                           <option value="VA">Virginia</option>
                           <option value="WA">Washington</option>
                           <option value="WV">West Virginia</option>
                           <option value="WI">Wisconsin</option>
                           <option value="WY">Wyoming</option>
                        </select>
                     </div>
                     <div class="mb-3">
                        <input type="email" name="email" class="form-control" placeholder="Email Address">
                     </div>
                     <div class="mb-3">
                        <input type="text" name="mobile" class="form-control" placeholder="Phone Number">
                     </div>
                  </div>
                  <div class="check-billing-address">
                     <input id="different-ship" name="billing_shiping" type="checkbox" checked="checked" value="yes">
                     <label for="box1"> <strong>Is your billing address same as shipping address? </strong></label>
                  </div>
                  <div class="mastercard-post d-flex p-3 my-4">
                     <div class="master-logo-img"> <img src="<?php echo WEBSITEURL; ?>images/masterCCLogo.png" class="img-fluid" alt="master card logo"> </div>
                     <p class="fs-15 fw-600 mb-0 ps-4"> Good News: Get $4.00 additional discount on shipping when you checkout with Mastercard! </p>
                  </div>
                  <div class="credit-card-info">
                     <div class="credit-info-header d-flex justify-content-between align-items-center mb-3">
                        <h6 class="fw-normal mb-0"> Credit Card Information:</h6>
                        <div class="crd-logo">
                           <img src="<?php echo WEBSITEURL; ?>images/masterCCLogo.png">
                           <img src="<?php echo WEBSITEURL; ?>images/visaCCLogo.png">
                        </div>
                     </div>
                     <div class="mb-3">
                        <input maxlength="16" name="card_number" id="ccnum" type="text" alt="Credit Card Number" class="form-control required" placeholder="____ ____ ____ ____" autocomplete="cc-number" aria-required="true">
                     </div>
                     <div class="mb-3 d-flex justify-content-between align-items-center">
                        <input id="cvv_number" type="text" placeholder="CVV" alt="CVV" class="form-control required" name="cvv_number" minlength="3" maxlength="4" autocomplete="cc-csc" aria-required="true">
                        <a href="#" class="cvv_img ps-3"> <img src="<?php echo WEBSITEURL; ?>images/cvv-img2.png"> </a>
                     </div>
                  </div>
                  <div id="expForm" class="d-flex justify-content-between align-items-center mb-3" >
                     <h6 class="fw-normal"> Expiration:</h6>
                     <div class="row">
                        <div class="mb-3 col-6">
                           <select id="ccexpmonth" name="cxpire_month" class="form-control">
                              <option value="" selected="selected">Month</option>
                              <option value="01">(01) Jan</option>
                              <option value="02">(02) Feb</option>
                              <option value="03">(03) Mar</option>
                              <option value="04">(04) Apr</option>
                              <option value="05">(05) May</option>
                              <option value="06">(06) June</option>
                              <option value="07">(07) July</option>
                              <option value="08">(08) Aug</option>
                              <option value="09">(09) Sep</option>
                              <option value="10">(10) Oct</option>
                              <option value="11">(11) Nov</option>
                              <option value="12">(12) Dec</option>
                           </select>
                        </div>
                        <div class="mb-3 col-6">
                           <select id="ccexpyear" name="cxpire_year" class="form-control">
                              <option selected="selected">Year</option>
                              <option value="21">2021</option>
                              <option value="22">2022</option>
                              <option value="23">2023</option>
                              <option value="24">2024</option>
                              <option value="25">2025</option>
                              <option value="26">2026</option>
                              <option value="27">2027</option>
                              <option value="28">2028</option>
                              <option value="29">2029</option>
                              <option value="30">2030</option>
                           </select>
                        </div>
                     </div>
                  </div>
                  <div class="check-fitness py-3 text-center">
                     <input type="checkbox" checked="checked" value="yes">
                     <label> <strong class="fs-14">Add a Fitzoo Fitness App for only $0.00  </strong></label>
                  </div>
                  <div class="btn-order-now">
                     <button type="submit" class="submit submit-disable" id="form-submit">
                     <span class="text-uppercase text-white">COMPLETE PURCHASE</span>
                     </button>
                     <div class="order_offer_form_responce"></div>
                  </div>
               </form>
                    
               <div class="terms-conditions-text py-2">
                  <p class="fs-15 mb-0"> By submitting, you affirm to have read and agreed to our <a href="#"> Terms & Conditions. </a></p>
               </div>
               <div class="guaranteed-checkout-text py-3 text-center">
                  <p> GUARANTEED <span style="color: #29af5c;">SAFE</span> CHECKOUT </p>
                  <img src="<?php echo WEBSITEURL; ?>images/safecheckout-logo.png" class="img-fluid">
               </div>
            </div>
         </div>
      </div>
   </section>
   <!--icon text section-->
   <section class="icon-text-section my-4 py-3">
      <div class="container">
         <div class="row">
            <div class="col-md-4">
               <div class="img-content-box text-center">
                  <img src="<?php echo WEBSITEURL; ?>images/item-1.png" class="img-fluid">
                  <p class="pt-3"> Stay Connected Without Having To <br>Check Your Phone Every 5 Seconds</p>
               </div>
            </div>
            <div class="col-md-4">
               <div class="img-content-box text-center">
                  <img src="<?php echo WEBSITEURL; ?>images/item-2.png" class="img-fluid">
                  <p class="pt-3"> Monitor Your Calories, Steps,Blood Pressure Instantly</p>
               </div>
            </div>
            <div class="col-md-4">
               <div class="img-content-box text-center">
                  <img src="<?php echo WEBSITEURL; ?>images/item-3.png" class="img-fluid">
                  <p class="pt-3"> Rain or Shower, Never Take It Off With IP6/7 Waterproof Features</p>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!--testimonial section-->
   <section class="testimonial-section mb-4">
      <div class="container">
         <div class="row">
            <!--1-->
            <div class="col-md-4">
               <div class="testimonial-content-block d-flex border p-3 mb-4 mb-md-0">
                  <div class="client-image">
                     <img src="<?php echo WEBSITEURL; ?>images/avt-1.jpg" class="img-fluid"> 
                  </div>
                  <div class="client-comment ps-3 fs-14">
                     <ul class="rating-star d-flex list-unstyled mb-2">
                        <li> <i class="fa fa-star" aria-hidden="true"></i> </li>
                        <li> <i class="fa fa-star" aria-hidden="true"></i> </li>
                        <li> <i class="fa fa-star" aria-hidden="true"></i> </li>
                        <li> <i class="fa fa-star" aria-hidden="true"></i> </li>
                        <li> <i class="fa fa-star" aria-hidden="true"></i> </li>
                     </ul>
                     <p class="mb-2"><strong>Verified Purchase</strong></p>
                     <p class="comment-text">My niece loves her new Fusion Smart Watch. I’m amazed at how many different things the watch does. 
                        She finally stopped asking me for one of those other over-priced e-watches which do exactly the same thing but for way more money. 
                        This was a great deal.
                     </p>
                     <div class="clent-name text-end">
                        <strong>Brenda M. <br>Cincinnati, OH</strong>
                     </div>
                  </div>
               </div>
            </div>
            <!--2-->
            <div class="col-md-4">
               <div class="testimonial-content-block d-flex border p-3 mb-4 mb-md-0">
                  <div class="client-image">
                     <img src="<?php echo WEBSITEURL; ?>images/avt-2.jpg" class="img-fluid"> 
                  </div>
                  <div class="client-comment ps-3 fs-14">
                     <ul class="rating-star d-flex list-unstyled mb-2">
                        <li> <i class="fa fa-star" aria-hidden="true"></i> </li>
                        <li> <i class="fa fa-star" aria-hidden="true"></i> </li>
                        <li> <i class="fa fa-star" aria-hidden="true"></i> </li>
                        <li> <i class="fa fa-star" aria-hidden="true"></i> </li>
                        <li> <i class="fa fa-star" aria-hidden="true"></i> </li>
                     </ul>
                     <p class="mb-2"><strong>Verified Purchase</strong></p>
                     <p class="comment-text">After a week of heavy research and reading reviews, I decided on an Fusion Smart Watch.
                        I’m so glad I did. The battery life is great, the feel is awesome, and it’s jammed pack with so many settings and it has a classy, stylish look.
                        I recommend this for the novice as well as hard core exercise individual. I'm in love with my Fusion Smart Watch.
                     </p>
                     <div class="clent-name text-end">
                        <strong>Jean B.  <br>Raleigh, NC </strong>
                     </div>
                  </div>
               </div>
            </div>
            <!--3-->
            <div class="col-md-4">
               <div class="testimonial-content-block d-flex border p-3 mb-4 mb-md-0">
                  <div class="client-image">
                     <img src="<?php echo WEBSITEURL; ?>images/avt-3.jpg" class="img-fluid"> 
                  </div>
                  <div class="client-comment ps-3 fs-14">
                     <ul class="rating-star d-flex list-unstyled mb-2">
                        <li> <i class="fa fa-star" aria-hidden="true"></i> </li>
                        <li> <i class="fa fa-star" aria-hidden="true"></i> </li>
                        <li> <i class="fa fa-star" aria-hidden="true"></i> </li>
                        <li> <i class="fa fa-star" aria-hidden="true"></i> </li>
                        <li> <i class="fa fa-star" aria-hidden="true"></i> </li>
                     </ul>
                     <p class="mb-2"><strong>Verified Purchase</strong></p>
                     <p class="comment-text">My first smartwatch and I'm in love with this thing. Tons of features and activities to record and I 
                        keep discovering new things every day. This watch exceeded my expectations. Buy it, you'll love it.
                     </p>
                     <div class="clent-name text-end">
                        <strong>Mike S. <br>Atlanta, GA</strong>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!--faq section-->
   <section class="faq-section color-bg py-4">
      <div class="container">
      <div class="row">
         <div class="col-md-12">
            <div class="faq-title text-center">
               <h6 class="fw-normal"> Have a Question? <u> See Our FAQs  </u> </h6>
            </div>
            <div class="faq-content-block py-4">
               <div class="accordion accordion-flush" id="accordionFlushExample">
                  <div class="accordion-item  mb-3 py-3">
                     <h2 class="accordion-header" id="flush-headingOne">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                           <h6 class="w_toptext mb-0"><span class="pe-3">Question:</span>Is Fusion Smart Watch difficult to use?</h6>
                        </button>
                     </h2>
                     <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                        <div class="accordion-body">
                           <p class="mb-0">The Fusion Smart Watch is not difficult to use at all. If you’re at all familiar with e-watches then you’ll have no problem navigating the 
                              Fusion Smart Watch. Its intuitive design is great for novices, as well.
                           </p>
                        </div>
                     </div>
                  </div>
                  <!--2-->
                  <div class="accordion-item mb-3 py-3">
                     <h2 class="accordion-header" id="flush-headingTwo">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
                           <h6 class="w_toptext mb-0"><span class="pe-3">Question:</span>What are some of the features of Fusion Smart Watch I can look forward to?</h6>
                        </button>
                     </h2>
                     <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
                        <div class="accordion-body">
                           <p class="mb-0">The Fusion Smart Watch is a very technologically advanced e-watch. It can monitor your heart rate, your sleep patterns, and also your physical activity. It can also perform the same functions as most e-watches on the market.</p>
                        </div>
                     </div>
                  </div>
                  <!--3-->
                  <div class="accordion-item mb-3 py-3">
                     <h2 class="accordion-header" id="flush-headingthree">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapsethree" aria-expanded="false" aria-controls="flush-collapsethree">
                           <h6 class="w_toptext mb-0"><span class="pe-3">Question:</span>Can I sync it with my iOS device? What about Android?</h6>
                        </button>
                     </h2>
                     <div id="flush-collapsethree" class="accordion-collapse collapse" aria-labelledby="flush-headingthree" data-bs-parent="#accordionFlushExample">
                        <div class="accordion-body">
                           <p class="mb-0"> Yes! The Fusion Smart Watch is fully-compatible with both iOS and Android smartphone models. </p>
                        </div>
                     </div>
                  </div>
                  <!--4-->
                  <div class="accordion-item mb-3 py-3">
                     <h2 class="accordion-header" id="flush-headingfour">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapsefour" aria-expanded="false" aria-controls="flush-collapsefour">
                           <h6 class="w_toptext mb-0"><span class="pe-3">Question:</span>How durable is the Fusion Smart Watch?</h6>
                        </button>
                     </h2>
                     <div id="flush-collapsefour" class="accordion-collapse collapse" aria-labelledby="flush-headinfour" data-bs-parent="#accordionFlushExample">
                        <div class="accordion-body">
                           <p class="mb-0">
                              Very durable. Ultra resistant aluminum casing combined with double-sided tempered glass makes the Fusion Smart Watch extremely durable. In addition, it has a very dependable battery which will last for several days. The Fusion Smart Watch was built for durability and longevity, which is why it also makes an excellent gift.
                           </p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!--footer-->
   <footer class="py-5 footer-bg">
      <div class="container py-4">
         <div class="row">
            <div class="col-md-12">
               <div class="footer-content-copyright d-md-flex justify-content-center fs-12 mb-3 text-center">
                  <p class="copyright  text-white me-3 fw-bold"> © 2021 Fusion Smart Watch — All rights reserved. </p>
                  <p class="customerservice  text-white"> Customer Service: (844) 307-4741 </p>
               </div>
               <ul class="d-flex justify-content-center list-unstyled mb-2 fs-12">
                  <li class="text-white"> <a href="#" class="text-decoration-none"> Terms & Conditions </a> <span class="px-2 line-footer text-white"> | </span> </li>
                  <li class="text-white"> <a href="#" class="text-decoration-none"> Privacy Policy </a> <span class="px-2 line-footer text-white"> | </span> </li>
                  <li class="text-white"> <a href="#" class="text-decoration-none"> Contact Us </a></li>
               </ul>
            </div>
         </div>
      </div>
   </footer>
   </div>

<?php include_once('footer.php'); ?>