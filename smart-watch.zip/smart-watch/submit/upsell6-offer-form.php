  <?php include_once('../config.php');
  
    $upsellId = $_POST['upsellId'];
    $upsell = $_POST['upsell'];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, SITEURL);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, true);
    
    $parameters = array(
        'user_auth' => array(
        'crm_user' => CRMUSER,
        'crm_user_password' => CRMPASSWORD,
        'upsellId' => $upsellId,
        'campaignId'  => CAMPAIGNID,
        'upsell' => [array(
                'upsell_id' => $upsell
            )]
        ),
    );
    $json = json_encode($parameters);
    $postArgs = array(
        'method' => 'newupsaleorder',
        'input_type' => 'JSON', 
        'response_type' => 'JSON',
        'rest_data' => $json,
        );
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postArgs);
    $output = curl_exec($ch);
    $info = curl_getinfo($ch);
    curl_close($ch);  
    //echo $output;
    //echo $output;
    //exit;
    $message = (json_decode($output));
    //echo "<pre>";
    //print_r($message);
    //exit;
    if($message->status == '200'){
      //echo "<p style='color:green;'>Please wait...</p>";
      //Store Session
        $_SESSION['upsell_payment_step'] = "thank-you.php";
        $_SESSION['upsellid'] = $upsellId;
      ?>
      <script>
          setTimeout(function(){ 
                window.location.href = '<?php echo WEBSITEURL.'thank-you.php'; ?>';
            }, 1000); 
      </script>
      <?php
    }else{
       echo "<p style='color:red;'>'.$output.'</p>";
    }
?>