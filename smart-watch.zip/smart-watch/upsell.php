<?php include_once('header.php'); ?>

  <body>
   
   <?php 
    //check all file session type
    //FITZOO APP UPSELL = upsell-1.php
    // DIZE PODS UPSELL = upsell-2.php
    //DIZE PODS CASE UPSELL = upsell-3.php
    //DIZE MINI SPEAKER UPSELL =upsell-4.php
    //BIOGLOVE UPSELL = upsell-5.php
    //RAPID TEST UPSELL = upsell-6.php
    //PROVEN PASS UPSELL = upsell-7.php 
   // echo $_SESSION['upsell_payment_step'];
   // exit;
   if($_SESSION['upsell_payment_step'] == "upsell-11.php"){
       include_once('upsell-11.php');
   } elseif($_SESSION['upsell_payment_step'] == "upsell-22.php") {
       include_once('upsell-22.php');
   } elseif($_SESSION['upsell_payment_step'] == "upsell-33.php") {
       include_once('upsell-33.php');
   } elseif($_SESSION['upsell_payment_step'] == "upsell-44.php") {
       include_once('upsell-44.php');
   } elseif($_SESSION['upsell_payment_step'] == "upsell-55.php") {
      include_once('upsell-55.php');
   } elseif($_SESSION['upsell_payment_step'] == "upsell-66.php") {
       include_once('upsell-66.php');
   } elseif($_SESSION['upsell_payment_step'] == "thank-you.php") {
        header("Location: ".WEBSITEURL."thank-you.php");
        exit;
   } else {
        header("Location: ".WEBSITEURL);
        exit;
   } 
   ?>
   <div class="upsell_payment_step_responce"></div>
   <!--Order_offer_form_popup Modal Start-->
    <div class="modal fade" id="buy_upsell_checkout_popup" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog ajax-popup"> 
        <div class="modal-content">
          <div class="modal-header">
            
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <p class="popmodel-p1">SUBMITTING YOUR INFORMATION...</p>
            <p class="popmodel-p2" style="display:none;">ALMOST DONE. PLEASE BE PATIENT...</p>
          </div>
        </div>
      </div>
    </div>
    <script>
        $('#buy_upsell_checkout_popup').modal('show');
        setTimeout(function(){ 
            $('.popmodel-p1').hide();
            $('.popmodel-p2').show(); 
        }, 3000); 
    </script>
    <!--Order_offer_form_popup Modal End-->
   <?php include_once('footer.php'); ?>