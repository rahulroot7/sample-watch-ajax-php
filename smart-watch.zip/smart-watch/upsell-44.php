<div class="upsell_payment_step_responce_default">
   <section class="product-detail py-2 py-md-3">
      <div class="container">
         <div class="row g-0">
            <div class="col-md-12">
               <div class="sub-header globe text-center pb-5">
                  <h3 class="banner-heading heading-text-cstm fw-bold">Get More BioGlove to Protect your entire family</h3>
                  <p class="mb-2 fw-bold"> 
                     Make sure every family member or member of your travel party always has Bioglove in their pocket.
                  </p>
               </div>
            </div>
         </div> 
      </div> 
      <div class="container">
         <div class="card border-0">
            <div class="row ">
               <div class="col-md-6">
                  <div class="d-flex flex-column justify-content-center text-center">
                     <div class="main_image border-bottom"> <img src="<?php echo WEBSITEURL; ?>images/ppocket-spayer-product.png" id="main_product_image" class="img-fluid"> </div>
                     <div class="thumbnail_images">
                        <ul id="thumbnail" class="d-flex justify-content-center list-unstyled mt-3">
                           <li><img onclick="changeImage(this)" src="<?php echo WEBSITEURL; ?>images/ppocket-spayer-product.png" width="70"></li>
                           <li><img onclick="changeImage(this)" src="<?php echo WEBSITEURL; ?>images/ppocket-sprayer.png" width="70"></li>
                        </ul>
                     </div>
                  </div>
               </div>
               <div class="col-md-6">
                  <div class="product-detail">
                     <h1 class="banner-sub-head m-0 p-0 fw-bold">Additonal Biogove Skin Sanitizer?</h1>
                     <hr class="m-1">
                     <div class="price-product  py-2">
                        <table class="a-lineitem">
                           <tbody>
                              <tr>
                                 <td class="fw-600">Price:</td>
                                 <td class="ps-2">
                                    <span class="text-clr fw-600">$9.95</span>
                                 </td>
                              </tr>
                           </tbody>
                        </table>
                     </div>
                  </div>
                  <div class="product-quantity d-flex py-2 align-items-center">
                     <p class="mb-0 pe-2 fw-600"> Quantity :</p>
                     <div class="quantity-add">
                        <button class="minus btn">-</button>
                        <input class="number btn" type="text" Value="1"> 
                        <button class="plus btn">+</button>
                     </div>
                  </div>
                  <div class="buy-product-btn py-2">
                     <ul class="list-unstyled d-xl-flex d-md-inline-block d-sm-flex align-items-center">
                        <button type="button" class="btn btn-primary btn-cart text-uppercase me-3 buy_upsell_checkout4" data-upsellId="<?php echo $_SESSION['upsellid']; ?>" data-upsell="<?php echo UPSELLID4; ?>">Add BioGlove</button>
                        <li><a href="#" class="link-cstm-cs text-clr">No Additonal Biogove Skin Sanitizer Needed</a></li>
                     </ul>
                     <div class="buy_upsell_checkout4_responce"></div>
                  </div>
                  <div class="about-this py-2">
                     <h5 class="pb-2 fw-600"> Antimicrobial Skin Protection</h5>
                     <ul class="ps-2 mb-0">
                        <li>12-Hour Skin Protection with One Application</li>
                        <li>Kills Bacteria, Viruses, Fungi on Contact</li>
                        <li>Alcohol-Free Formulation</li>
                        <li>Gently Moisturizes Skin</li>
                        <li>100% Triclosan, Paraben, Sulfate & Alcohol-Free</li>
                        <li>All-Day Germ Protection for Pennies</li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <section class="next-gene-sec-cont mb-4 mb-md-5 pb-0 pb-lg-5 position-relative">
      <div class="container">
         <div class="row">
            <div class="hours-12-Antimicrobial-img d-xl-none d-block ">
               <img src="<?php echo WEBSITEURL; ?>images/12-hours-Antimicrobial-img.png" alt="12 Hours Antimicrobial" class="img-fluid">
            </div>
            <div class="col-xl-6">
               <h1 class="banner-sub-head mb-4 p-0 mt-4 mt-md-0">Next Generation <span>Invisible Glove Technology</span></h1>
               <ul class="about-this pl-3 mb-0">
                  <li>BiOGLOVE Hand Sanitizer & Skin Protectant persistently kills 99.9% of common germs* that may cause illness or disease for up to 12 hours and 10 hand washings! (*germs => bacteria, viruses, fungi and other pathogens)
                  </li>
                  <li>Non-flammable and 100% Triclosan, Paraben, Sulfate and Alcohol-Free!
                  </li>
                  <li>Contains soothing botanicals to help moisturize your hands and prevent dry, chapped, irritated skin.
                  </li>
                  <li>A better value than alcohol-based hand sanitizers which evaporate and stop working seconds after application. One application of BiOGLOVE protects your hands from germs all day!
                  </li>
                  <li>Environmentally friendly and responsible compared to single-use disposables gloves and wipes.
                  </li>
                  <li> Convenient, personal size USB-rechargeable electrostatic atomizer and finger-pump sprayer types.
                  </li>
                  <li>Face-recognition with mask, temperature-reading, AI Intelligence, Android OS, WiFi, automated and refillable floor-stand & wall-mount commercial dispenser options.
                  </li>
               </ul>
            </div>
         </div>
      </div>
   </section>
    <section class="last-banner-image">
      <div class="banner_hand">
         <img src="<?php echo WEBSITEURL; ?>images/bioglove-kit-seimg.jpg" alt="bioglove kit" class="w-100">
      </div>
    </section>
    <!--product thumbnail script-->
    <script>
       function changeImage(element) {
           var main_prodcut_image = document.getElementById('main_product_image');
           main_prodcut_image.src = element.src;
         }
    </script>
</div>