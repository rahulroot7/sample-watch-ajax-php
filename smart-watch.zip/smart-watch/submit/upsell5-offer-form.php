  <?php include_once('../config.php');
  
    $upsellId = $_POST['upsellId'];
    $upsell = $_POST['upsell'];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, SITEURL);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, true);
    
    $parameters = array(
        'user_auth' => array(
        'crm_user' => CRMUSER,
        'crm_user_password' => CRMPASSWORD,
        'upsellId' => $upsellId,
        'campaignId'  => CAMPAIGNID,
        'upsell' => [array(
                'upsell_id' => $upsell
            )]
        ),
    );
    $json = json_encode($parameters);
    $postArgs = array(
        'method' => 'newupsaleorder',
        'input_type' => 'JSON', 
        'response_type' => 'JSON',
        'rest_data' => $json,
        );
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postArgs);
    $output = curl_exec($ch);
    $info = curl_getinfo($ch);
    curl_close($ch);  
    //echo $output;
    //echo $output;
    //exit;
    $message = (json_decode($output));
    //echo "<pre>";
    //print_r($message);
    //exit;
    if($message->status == '200'){
        //echo "<p style='color:green;'>Please wait...</p>";
        //Store Session
        $_SESSION['upsell_payment_step'] = "upsell-66.php";
        $_SESSION['upsellid'] = $upsellId;
        ?>
        <script>
            $('.upsell_payment_step_responce_default').hide();
            $('#buy_upsell_checkout_popup').modal('hide');
        </script>
        <section class="roam-banner-img" style="background-image:url('<?php echo WEBSITEURL; ?>images/how-work-proven-img.jpg')">
              <div class="container-fluid banner-cw">
                 <div class="row">
                    <div class=" col-12 col-md-12 col-lg-5 ps-md-5">
                       <h1 class="banner-heading heading-text-cstm mb-3 fw-bold">Take your Life back with ProvenPass.<br>  Get tested on the fly and enjoy Life.</h1>
                       <p class="subhead mt-5 text-justify get-ready-para">Know the USA Membership Requirements:</p>
                       <p class="subhead mt-1 text-justify get-ready-para">All air passengers coming to the United States, including U.S. citizens
                          and fully vaccinated people, are required to have a negative COVID-19
                          test result no more than 3 days before boarding a flight to the United
                          States. 
                       </p>
                       <p class="pt-3 pb-5 py-sm-5 m-0"><span class="realistic-marker-highlight fw-bold" style="--highlighter-progress:1;">ONLY $7.95</span></p>
                       <div class="buy-product-btn">
                          <button class="btn text-white buy_upsell_checkout6"  data-upsellId="<?php echo $upsellId; ?>" data-upsell="<?php echo UPSELLID6; ?>"> Get your Membership </button>
                          <div class="buy_upsell_checkout6_responce"></div>
                       </div>
                    </div>
                    <div class=" col-12 col-md-12 col-lg-4 banner-image-wrap  d-flex align-items-center">
                       <img src="<?php echo WEBSITEURL; ?>images/product-kit-spray.png" class="w-100 banner-desktop-inner">
                       <img src="<?php echo WEBSITEURL; ?>images/mobile-product-kit-spray.png" class="w-100 banner-mobile-inner">
                    </div>
                 </div>
              </div>
           </section>
           <section class="member-proven-link py-5" style="background-image:url('<?php echo WEBSITEURL; ?>images/proven-pass-td-bg.jpg')">
              <div class="image-wrap text-center">
                 <img src="<?php echo WEBSITEURL; ?>images/get-gpay-logo.png" class="pb-2">  
                 <img src="<?php echo WEBSITEURL; ?>images/download-app-store-logo.png" class="px-md-4 pb-2">  
                 <img src="<?php echo WEBSITEURL; ?>images/proven-regis-logo.png " class="pb-2">  
              </div>
           </section>
           <section class="companies-partner py-5 text-center">
              <h2 class="fw-bold title-heading pb-5"> Companies using Us &amp; Partners </h2>
              <img src="<?php echo WEBSITEURL; ?>images/companies-partner.jpg" class=""> 
           </section>
           <section class="proven-logo-sec py-5" style="background-image:url('<?php echo WEBSITEURL; ?>images/what-proven-bg.jpg')">
              <div class="container">
                 <div class="row align-items-center">
                    <div class="col-md-4">
                       <img src="<?php echo WEBSITEURL; ?>images/proven-logo-1.png" class="img-fluid">  
                    </div>
                    <div class="col-md-8">
                       <h3 class="text-clr"> Partnering with organizations across the globe to safely reopen </h3>
                    </div>
                 </div>
              </div>
           </section>
           <section class="enjoy-visit-cont py-5">
              <!--text-section-->
              <div class="container">
                 <div class="row">
                    <div class="col-md-12">
                       <div class="text-content-block text-center  cv-space">
                          <h2 class="title-heading">Get back to enjoying your life and safely take your Covid-19 test from anywhere at anytime, to ensure you have the proper documents available when they are needed.</h2>
                       </div>
                    </div>
                 </div>
              </div>
           </section>
           <section class="member-footer-banner">
              <img src="<?php echo WEBSITEURL; ?>images/member-footer-banner.jpg" alt="Travel Covid Kit" class="w-100">
           </section>
      <?php
    }else{
       echo "<p style='color:red;'>'.$output.'</p>";
    }
?>