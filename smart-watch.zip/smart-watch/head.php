<?php include_once("config.php"); ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSS -->
    <link href="<?php echo WEBSITEURL; ?>css/bootstrap.min.css" rel="stylesheet">
     <link href="<?php echo WEBSITEURL; ?>css/style.css" rel="stylesheet">
     <link href="<?php echo WEBSITEURL; ?>css/custom.css" rel="stylesheet">
     
       <link href="<?php echo WEBSITEURL; ?>css/bioglove.css" rel="stylesheet">
     <!-- Font awseom -->
	 <!-- Font awseom -->
	   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title> Fusion Smart Watch </title>
    
    <!--Bootstrap Bundle with Popper -->
   <script src="<?php echo WEBSITEURL; ?>js/jquery.min.js"></script>
   <script src="<?php echo WEBSITEURL; ?>js/bootstrap.bundle.min.js"></script>
    <script>
        //base_url
		var base_url = '<?php echo WEBSITEURL; ?>'; 
	</script>
  </head>