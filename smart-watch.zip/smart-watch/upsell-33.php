<div class="upsell_payment_step_responce_default">
    <section class="warning-banner-section">
     <div class="container">
      <div class="row">
       <div class="col-md-7 mx-auto">
           <div class="warning_banner pb-2 px-3 px-md-0">
             <div class="progress mb-3">
                <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="width: 100%"></div>
            </div>
            <h2 class="text-white fw-bold text-center mb-0"> <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>  WAIT  <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
            </h2>
            <div class="warning-content text-center">
                <h2 class="fw-bold text-white text-uppercase"> <?php echo $_SESSION['customer_name']; ?></h2>
               <h5 class="text-white text-uppercase"> YOUR ORDER IS NOT COMPLETE </h5>
            </div>
           </div>
           <!--text-->
            <div class="add-copy text-center py-3">
                <h4 class="fw-normal"> Your Fusion Smart Watch Order </h4>
                 <h4> 
                    <span class="fw-bold">Qualified You For A</span><br> 
                    <span class="fw-bold">Dize Mini Speaker</span>
                </h4>
            </div>
          <!--congrats section-->
          <div class="congrats_block text-center fs-14">
              <p class="mb-0"> <span class="danger-text"> WARNING: </span> There are only </p>
              <p class="mb-0"> <span class="danger-text"> 2 Units </span>  Left in Stock! </p>
              
          </div>
          <!--offer expires-->
           <div class="offer-expires-block text-center py-2">
               <h4 class="fw-bold danger-text expire-offer-text py-3"> Your offer expires in 0:01 </h4>
           </div>
           <!--product inner banner-->
            <div class="product-inner-banner">
                <img src="<?php echo WEBSITEURL; ?>images/mini-speaker.jpg" class="img-fluid">
            </div>
            
            <div class="product-description-content my-5">
                <h6 class="pt-3"> About this item  </h6>
                <ul class="p-0">
                    <li> Compact & Powerful : High Quality Certified Wireless Portable </li>
                    <li> Is The Ultimate, High-Powered Portable Bluetooth Speaker With Powerful Stereo Sound. A Built-In Noise And Echo-Cancelling Speakerphone Gives You Crystal Clear Calls With The Press Of a Button. </li>
                    <li> Support BT Music, BT Handsfree Call, LINE-IN, Remote Shutter Built in a stereo loudspeaker, a microphone. Tiny but loud, with super bass sound system. </li>
                </ul>
                
               <h6 class="pt-3">  Details: </h6>
                <ul class="p-0">
                    <li> Single-channel portable speaker</li>
                    <li> Supporting TF card (maximum capacity can reach to 8G) and with AUX input</li>
                    <li> Using low-frequency enhancement technology</li>
                    <li>Using anti-breaking sound''s technology</li>
                    <li> With mini SD card function and Li battery </li>
                </ul>
               
                
            </div>
            
            
       </div>
      </div>
     </div>  
   </section>
    
    <div class="container-fluid px-5 pt-4 checkout-button">
        <div class="row">
         <div class="col-md-12">
             <div class="submit-button__wrapper text-center">
                 <button class="btn text-white buy_upsell_checkout3" data-upsellId="<?php echo $_SESSION['upsellid']; ?>" data-upsell="<?php echo UPSELLID3; ?>"> Complete Checkout  </button>
                  <div class="buy_upsell_checkout3_responce"></div>
             </div>
             <p class="add-small-text text-center mb-2"> JUST ADD $24.99 FOR SHIPPING </p>
         </div> 
        </div>
    </div>
    <div class="banner-bottom">
       <img src="<?php echo WEBSITEURL; ?>images/mini-spaker-bg.jpg" class="img-fluid">
    </div>
</div>