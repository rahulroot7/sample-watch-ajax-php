<?php include_once('head.php'); ?>
<body>
   <!--thank you message block-->
   <section class="thankyou-message-section py-3">
      <div class="container">
         <div class="row">
            <div class="col-md-12">
               <div class="thankyou-message-header text-center">
                  <h3 class="mb-0 fw-bold">Thank You For Your Order!</h3>
                  <h4 class="mb-0 py-3 fw-bold">Your orders are currently being processed and will ship promptly.</h4>
                  <h5 class="mb-0 fw-bold">Orders Placed: December 1, 2021</h5>
               </div>
            </div>
         </div>
         <div class="row py-3">
            <div class="col-md-5 col-sm-5">
               <div id="address-detail" class="main-border">
                  <div id="shipping" class="p-3 pb-0">
                     <p><strong>Shipping Info:</strong></p>
                     <p class="info">Sandra Smith</p>
                     <p class="info">237 E DALTON RD</p>
                     <p class="info">ELLENBORO, NC 28040</p>
                     <p class="info">United States</p>
                  </div>
                  <div id="billing" class="p-3 pb-0">
                     <p><strong>Billing Info:</strong></p>
                     <p class="info">Sandra Smith</p>
                     <p class="info">237 E DALTON RD</p>
                     <p class="info">ELLENBORO, NC 28040</p>
                     <p class="info">United States</p>
                  </div>
               </div>
            </div>
            <div class="col-md-7 col-sm-7">
               <div id="receipt-detail" class="main-border">
                  <!--1-->
                  <div class="receipt-product-detail d-md-flex align-items-center py-2">
                     <img src="<?php echo WEBSITEURL; ?>images/product.png" class="img-fluid">
                     <div class="description-detail ps-4">
                        <p class="shipmentnumber fw-300">Order #2195536 </p>
                        <p class="description order-desc"> Fusion Smart Watch </p>
                        <p class="details fw-300"> Customer Support: <span></span> </p>
                        <div class="totalamounts order-desc mb-0">
                           <p>$5.95</p>
                        </div>
                     </div>
                  </div>
                  <!--2-->
                  <div class="receipt-product-detail d-md-flex align-items-center py-2">
                     <img src="<?php echo WEBSITEURL; ?>images/product2.jpg" class="img-fluid">
                     <div class="description-detail ps-4">
                        <p class="shipmentnumber ">Order #2195536  </p>
                        <p class="description order-desc"> Fitzoo Fitness App </p>
                        <p class="details fw-300"> Customer Support: <span></span> </p>
                        <div class="totalamounts order-desc mb-0">
                           <p>$0.00</p>
                        </div>
                     </div>
                  </div>
                  <!--3-->
                  <div class="receipt-product-detail d-md-flex align-items-center py-2">
                     <img src="./images/product3.jpg" class="img-fluid">
                     <div class="description-detail ps-4">
                        <p class="shipmentnumber ">Order #2195887  </p>
                        <p class="description order-desc"> Rize Pods </p>
                        <p class="details fw-300"> Customer Support: <span></span> </p>
                        <div class="totalamounts order-desc mb-0">
                           <p>$5.95</p>
                        </div>
                     </div>
                  </div>
                  <!--4-->
                  <div class="receipt-product-detail d-md-flex align-items-center py-2">
                     <img src="<?php echo WEBSITEURL; ?>images/product4.png" class="img-fluid">
                     <div class="description-detail ps-4">
                        <p class="shipmentnumber ">Order #2195536  </p>
                        <p class="description order-desc"> Fitzoo Fitness App </p>
                        <p class="details fw-300"> Customer Support: <span></span> </p>
                        <div class="totalamounts order-desc mb-0">
                           <p>$0.00</p>
                        </div>
                     </div>
                  </div>
                  <!--5-->
                  <div class="receipt-product-detail d-md-flex align-items-center py-2">
                     <img src="<?php echo WEBSITEURL; ?>images/product5.jpg" class="img-fluid">
                     <div class="description-detail ps-4">
                        <p class="shipmentnumber ">Order #2195536  </p>
                        <p class="description order-desc"> Fitzoo Fitness App </p>
                        <p class="details fw-300"> Customer Support: <span></span> </p>
                        <div class="totalamounts order-desc mb-0">
                           <p>$0.00</p>
                        </div>
                     </div>
                  </div>
                  <!--subtotal billing-->
                  <div class="subtotal-billing-blk">
                     <div class="row">
                        <div class="col-md-4"></div>
                        <div class="col-md-8">
                           <div id="subtotal-bill" class="pt-3 px-3">
                              <table class="w-100">
                                 <tbody class="fw-300">
                                    <tr>
                                       <td>
                                          <p class="description totals">Item(s) Subtotal:</p>
                                       </td>
                                       <td>
                                          <p class="rprice totals">$0.00</p>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td>
                                          <p class="description totals">Shipping &amp; Handling&nbsp;&nbsp;</p>
                                       </td>
                                       <td>
                                          <p class="rprice totals">$61.88</p>
                                       </td>
                                    </tr>
                                    <tr class="bold">
                                       <td>
                                          <p class="description totals">Total</p>
                                       </td>
                                       <td>
                                          <p class="rprice totals">$61.88</p>
                                       </td>
                                    </tr>
                                 </tbody>
                              </table>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
    <?php //unset session here
        unset($_SESSION["customer_name"]);
        unset($_SESSION["upsell_payment_step"]);
        unset($_SESSION["upsellid"]);
    ?>
   <script>
    setTimeout(function(){ 
           window.location.href = '<?php echo WEBSITEURL; ?>';
      }, 6000);
   </script> 
   <?php include_once('footer.php'); ?>