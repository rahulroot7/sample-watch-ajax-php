<?php include_once('../config.php');
    
     $customer_name = trim($_GET['firstname'])." ".trim($_GET['lastname']);
     $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, SITEURL);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_POST, true);
           $parameters = array(
          'user_auth' => array(
              'crm_user' => CRMUSER,
              'crm_user_password' =>CRMPASSWORD,
              'first_name'  => trim($_GET['firstname']),
              'last_name'  => trim($_GET['lastname']),
              'email'  => trim($_GET['email']),
              'phone_home'  => trim($_GET['mobile']),
              'bill_address_line1' => $_GET['address'],
              'bill_city' => trim($_GET['city']),
              'bill_state' => trim($_GET['state']),
              'bill_postal' => trim($_GET['zip_code']),
              'bill_country' => 'US',
              //'bill_ship_same' =>trim($_GET['bill_ship_same']),
             // 'ship_address_line1' =>trim($_GET['fields_shipaddress1']),
              //'ship_city' =>trim($_GET['fields_shipcity']),
              //'ship_state' =>trim($_GET['fields_shipstate']),
              //'ship_postal' =>trim($_GET['fields_shipzip']),
              // 'ship_country' =>trim($_GET['ship_country']),
              'card_number'  => trim($_GET['card_number']),
              'expiration_month' => trim($_GET['cxpire_month']),
              'expiration_year'  => trim($_GET['cxpire_year']),
              'expiration_cvv'  => trim($_GET['cvv_number']), 

              'campaignId'  => CAMPAIGNID,
              'offer' => [array(
                      'offer_id' => OFFERID1
                  )]
              ),
          );
      $json = json_encode($parameters);
      $postArgs = array(
          'method' => 'temporder',
          'input_type' => 'JSON',
          'response_type' => 'JSON',
          'rest_data' => $json,
          );
      curl_setopt($ch, CURLOPT_POSTFIELDS, $postArgs);
      $output = curl_exec($ch);
      $info = curl_getinfo($ch);
      curl_close($ch);  
      /*echo $output;
      exit;*/
      $message = (json_decode($output));
      //echo "<pre>";
      //print_r($message);
      //echo $message->data->response[0]->status;
     // exit; 
      if($message->data->response[0]->status == 'approved'){ 
            $campaignId = $message->data->campaignId;
            $upsellid = $message->data->upsellid;
            //echo "<p style='color:green;'>Please wait...</p>";
            //Store Session
            $_SESSION['upsell_payment_step'] = "upsell-11.php";
            $_SESSION['upsellid'] = $upsellid; 
            $_SESSION['customer_name'] = $customer_name;
            ?>
            <!--Order_offer_form_popup Modal Start-->
            <div class="modal fade" id="order_offer_form_popup" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog ajax-popup"> 
                <div class="modal-content p-2">
                  <div class="modal-header">
                    
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body text-center">
                    <p class="popmodel-p1">SUBMITTING YOUR INFORMATION...</p>
                    <p class="popmodel-p2" style="display:none;">ALMOST DONE. PLEASE BE PATIENT...</p>
                    <img src="<?php echo WEBSITEURL; ?>images/popup-logo.jpg" class="img-fluid">
                  </div>
                </div>
              </div>
            </div>
            <script>
                $('#order_offer_form_popup').modal('show');
                setTimeout(function(){ 
                    $('.popmodel-p1').hide();
                    $('.popmodel-p2').show(); 
                }, 3000); 
            </script>
            <!--Order_offer_form_popup Modal End-->
          <script> 
              setTimeout(function(){ 
                    $('.tele_theraphy_responce').hide();
                    window.location.href = '<?php echo WEBSITEURL.'upsell.php'; ?>';   
                }, 4000); 
          </script>
          <?php
      }elseif ($message->data->response[0]->status == "declined"){
          echo "<p style='color:red;'>Payment declined please try again.</p>";
      } else{ 
          echo "<p style='color:red;'>Oops something wrong.</p>";
      }
?>