$(document).ready(function() {
    //Submit order_offer_form start 
    $("#order_offer_form").validate({
        rules: {
           firstname: "required",
            lastname: "required",
            email: {
                required: true,
                email: true,
            },
            address: "required",
            address2: "required",
            zip_code: "required",
            city: "required",
            state: "required",
            mobile: "required",
            card_number: "required",
            cvv_number: "required",
            cxpire_month: "required",
            cxpire_year: "required", 
        }, 
        messages: {
              //firstname: "Please enter your firstname",
        }
    })
    $('#order_offer_form').submit(function(e) {
        e.preventDefault();
        if ($('#order_offer_form').valid()) {
           // $('body').addClass("loader");
           // $(".loader-img").css("display", "flex");
           // $('.loader-img').show();
            $('.submit-disable').attr("disabled", true);
            $.post(base_url+"submit/order-offer-form.php?" + $("#order_offer_form").serialize(), {}, function(response) {
                //console.log(response);
                $('.order_offer_form_responce').html(response);
                $('.submit-disable').attr("disabled", false);
                // $('body').removeClass("loader");
                //$('.loader-img').hide();
            });
            return false;
        } 
    });
    //Submit order_offer_form order end
    
    //Code for buy_upsell_checkout1
    $(document).on("click",".buy_upsell_checkout1",function(e) {
        e.preventDefault();
        var upsellId = $(this).attr("data-upsellId");
        var upsell = $(this).attr("data-upsell");
         
        $.ajax({
            url : base_url+"submit/upsell1-offer-form.php",
            type : 'POST',
            data: {
                upsellId: upsellId,
                upsell: upsell    
            },
            beforeSend: function() {
                //$('body').addClass("loader");
                //$(".loader-img").css("display", "flex");
                //$('.loader-img').show();
                $('#buy_upsell_checkout_popup').modal('show');
                $('.buy_upsell_checkout1').attr("disabled", true);
            },
            success : function (response) {
                // $('.buy_upsell_checkout1_responce').html(response);
                $('.upsell_payment_step_responce').html(response);
                $('.buy_upsell_checkout1').attr("disabled", false);
                //$('body').removeClass("loader");
               // $('.loader-img').hide();
            } 
       });
    });
    
    //Code for buy_upsell_checkout2
    $(document).on("click",".buy_upsell_checkout2",function(e) {
        e.preventDefault();
        var upsellId = $(this).attr("data-upsellId");
        var upsell = $(this).attr("data-upsell");
         
        $.ajax({
            url : base_url+"submit/upsell2-offer-form.php", 
            type : 'POST',
            data: {
                upsellId: upsellId,
                upsell: upsell    
            },
            beforeSend: function() {
                //$('body').addClass("loader");
                //$(".loader-img").css("display", "flex");
                //$('.loader-img').show();
                $('#buy_upsell_checkout_popup').modal('show');
                $('.buy_upsell_checkout2').attr("disabled", true);
            },
            success : function (response) {
                // $('.buy_upsell_checkout2_responce').html(response);
                $('.upsell_payment_step_responce').html(response);
                $('.buy_upsell_checkout2').attr("disabled", false);
               // $('body').removeClass("loader");
                //$('.loader-img').hide();
            } 
       });
    });
    
    //Code for buy_upsell_checkout3
    $(document).on("click",".buy_upsell_checkout3",function(e) {
        e.preventDefault();
        var upsellId = $(this).attr("data-upsellId");
        var upsell = $(this).attr("data-upsell");
         
        $.ajax({
            url : base_url+"submit/upsell3-offer-form.php",
            type : 'POST',
            data: {
                upsellId: upsellId,
                upsell: upsell    
            },
            beforeSend: function() {
               // $('body').addClass("loader");
                //$(".loader-img").css("display", "flex");
                //$('.loader-img').show();
                $('.buy_upsell_checkout3').attr("disabled", true);
            },
            success : function (response) {
               // $('.buy_upsell_checkout3_responce').html(response);
                $('.upsell_payment_step_responce').html(response);
                $('.buy_upsell_checkout3').attr("disabled", false);
               // $('body').removeClass("loader");
                //$('.loader-img').hide();
            } 
       });
    });
    
    //Code for buy_upsell_checkout4
    $(document).on("click",".buy_upsell_checkout4",function(e) {
        e.preventDefault();
        var upsellId = $(this).attr("data-upsellId");
        var upsell = $(this).attr("data-upsell");
         
        $.ajax({
            url : base_url+"submit/upsell4-offer-form.php",
            type : 'POST',
            data: {
                upsellId: upsellId,
                upsell: upsell    
            },
            beforeSend: function() {
               // $('body').addClass("loader");
               // $(".loader-img").css("display", "flex");
               // $('.loader-img').show();
                $('.buy_upsell_checkout4').attr("disabled", true);
            },
            success : function (response) {
               // $('.buy_upsell_checkout4_responce').html(response);
                $('.upsell_payment_step_responce').html(response);
                $('.buy_upsell_checkout4').attr("disabled", false);
                //$('body').removeClass("loader");
               // $('.loader-img').hide();
            }  
       });
    });
    
    //Code for buy_upsell_checkout5
    $(document).on("click",".buy_upsell_checkout5",function(e) {
        e.preventDefault();
        var upsellId = $(this).attr("data-upsellId");
        var upsell = $(this).attr("data-upsell");
         
        $.ajax({
            url : base_url+"submit/upsell5-offer-form.php",
            type : 'POST',
            data: {
                upsellId: upsellId,
                upsell: upsell    
            },
            beforeSend: function() {
               // $('body').addClass("loader");
               // $(".loader-img").css("display", "flex");
               // $('.loader-img').show();
                $('.buy_upsell_checkout5').attr("disabled", true);
            },
            success : function (response) {
               // $('.buy_upsell_checkout5_responce').html(response);
                $('.upsell_payment_step_responce').html(response);
                $('.buy_upsell_checkout5').attr("disabled", false);
                //$('body').removeClass("loader");
               // $('.loader-img').hide();
            }  
       });
    });
    
    //Code for buy_upsell_checkout6
    $(document).on("click",".buy_upsell_checkout6",function(e) {
        e.preventDefault();
        var upsellId = $(this).attr("data-upsellId");
        var upsell = $(this).attr("data-upsell");
        
        $.ajax({
            url : base_url+"submit/upsell6-offer-form.php",
            type : 'POST',
            data: {
                upsellId: upsellId,
                upsell: upsell    
            },
            beforeSend: function() {
               // $('body').addClass("loader");
               // $(".loader-img").css("display", "flex");
               // $('.loader-img').show();
                $('.buy_upsell_checkout6').attr("disabled", true);
            },
            success : function (response) {
               // $('.buy_upsell_checkout4_responce').html(response);
                $('.buy_upsell_checkout6_responce').html(response);
                $('.buy_upsell_checkout6').attr("disabled", false);
                //$('body').removeClass("loader");
               // $('.loader-img').hide();
            }  
       });
    });
    
});