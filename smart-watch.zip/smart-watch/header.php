<?php include_once('head.php'); ?> 
<body class="">
    <!--Waiting load start-->
    <div class="main-popup progress-bg" style="display:none;">
        <div class="popup-logo">
            <img src="https://selodesign.com/smart-watch/images/logo.png" alt="" class="thk-logo my-3" style="max-width:220px">
                <p class="pop-p1">Checking if you qualify for special offers.</p>
                <p class="pop-p2" style="display: none;">Congratulations you qualified!</p>
                <p class="pop-p3" style="display: none;">Checking for stock!</p>
            <p class="pop-p4" style="display: none;">Stock Available!</p>
        </div><br>
        <div class="progress mt-3" style="width:30%">
          <div id="progress-bar" class="progress-bar progress-bar-striped" role="progressbar" style="width: 10%" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100"></div>
        </div>
    </div>
    <!--Waiting load start-->


    <!--Loader start-->
    <div class="loader-img" style="display:none;">
        <img class="loader-responce" src="<?php echo WEBSITEURL; ?>images/loading-buffering.gif" alt="loader-img.gif"> 
    </div>
   <!--header section-->
   <header class="text-center py-3">
      <h6 class="text-uppercase text-white fw-normal mb-0"> YOUR FUSION SMART WATCH HAS BEEN RESERVED!  </h6>
   </header>