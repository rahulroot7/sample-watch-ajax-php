jQuery(document).ready(function(){
    //term_conditions
    $(document).on("click",".term_conditions",function() {
        $('#termcondition').modal('show');
    });
    //privacy_policy
    $(document).on("click",".privacy_policy",function() {
        $('#privacypolicypage').modal('show');
    });
     //contact us
    $(document).on("click",".contact_us",function() {
        $('#contactus').modal('show');
    });
    
    //change billing details
    $('.different_ship_address').change(function(){
        if(this.checked){
             $('.billingaddress').show();
        } else {
            $('.billingaddress').hide();
        }
    });
    
    //quantity
         $(document).ready(function(){
          $(".plus").click(function(){
            var val= $(".number").val();
            val++;
            if(val >= 1){
              $(".number").attr("value", val);
            }
          });
          $(".minus").click(function(){
            var val= $(".number").val();
            val--;
            if(val >= 1){
              $(".number").attr("value", val);
            }
          });
          
           $('#buyupsell2').click(function(){
        var upsellId = $(this).attr("data-upsellId");
        var  quanity= $(".number").val();
        if(upsellId == ''){
          $('.errormsg').css('display','');
          $('.errormsg .errorcls').html("Upsell Id is required. Please <a href='https://provenpass.com/ofr/mbrsfn.php'>click here</a> to buy offer."); 
          return false;
        }
        var upsell = $(this).attr("data-upsell");
        $(this).css('pointer-events','none');
           $.ajax({
                     url : 'ajax.php',
                     type : 'POST',
                      data: {
                            upsellId: upsellId,
                            upsell: upsell,
                            quanity:quanity,
                            action: 'submitupsellform2',    
                    },
                     success : function (result) {
                         console.log(result);
                        $('.errormsg').css('display','none');
                       var objJSON = JSON.parse(result); 
                       if(objJSON.status == 200 ){
                           window.location.href = 'https://provenpass.com/ofr/thankyou.php';
                       }else{
                           $('.errormsg').css('display','');
                          $('.errormsg .errorcls').text(objJSON.data.response[0].status);
                          $("#buyupsell2").css('pointer-events',' ');
                       }
                       
                     },
                     error : function (error) {
                        console.log (error);
                         $("#buyupsell2").css('pointer-events',' ');
                     }
                   });
      
            });
             $('.btnclse').click(function(){
            $('.errormsg').css('display','none');
       });
        });
});