<div class="upsell_payment_step_responce_default">
   <section class="product-detail py-2 py-md-3">
      <div class="container">
         <div class="errormsg alert alert-info" style='display:none'>
            <div class="errorcls"></div>
            <button type="button" class="close btnclse"  aria-label="Close"><span aria-hidden="true">×</span></button>
         </div>
         <div class="row g-0">
            <div class="col-md-12">
               <div class="sub-header globe text-center pb-5">
                  <h3 class="banner-heading heading-text-cstm fw-bold">Get Additional Test Kits</h3>
                  <p class="mb-2 fw-bold"> 
                     If you are not traveling alone, we recommend you purchase 2 test kits for each family member or traveling in your party. 
                  </p>
               </div>
            </div>
         </div> 
      </div>
      <div class="container">
         <div class="card border-0">
            <div class="row ">
               <div class="col-md-6">
                  <div class="d-flex flex-column justify-content-center text-center">
                     <div class="main_image border-bottom pb-3"> <img src="<?php echo WEBSITEURL; ?>images/pro-1.1.jpg" id="main_product_image" class="img-fluid"> </div>
                     <div class="thumbnail_images">
                        <ul id="thumbnail" class="d-flex justify-content-center list-unstyled mt-3">
                           <li><img onclick="changeImage(this)" src="<?php echo WEBSITEURL; ?>images/pro-1.1.jpg" width="70"></li>
                           <li><img onclick="changeImage(this)" src="<?php echo WEBSITEURL; ?>images/pppro-1.2.jpg" width="70"></li>
                           <li><img onclick="changeImage(this)" src="<?php echo WEBSITEURL; ?>images/pro-1.3.jpg" width="70"></li>
                           <li><img onclick="changeImage(this)" src="<?php echo WEBSITEURL; ?>images/ppro-1.4.jpg" width="70"></li>
                        </ul>
                     </div>
                  </div>
               </div>
               <div class="col-md-6">
                  <div class="product-detail">
                     <h1 class="banner-sub-head m-0 p-0 fw-bold">Additonal Test Kits?</h1>
                     <hr class="m-1">
                     <div class="price-product  py-2">
                        <table class="a-lineitem">
                           <tbody>
                              <tr>
                                 <td class="fw-600">Price:</td>
                                 <td class="ps-2">
                                    <span class="text-clr fw-600">$15.95</span>
                                 </td>
                              </tr>
                           </tbody>
                        </table>
                     </div>
                  </div>
                  <div class="product-quantity d-flex py-2 align-items-center">
                     <p class="mb-0 pe-2 fw-600"> Quantity :</p>
                     <div class="quantity-add">
                        <button class="minus btn">-</button>
                        <input class="number btn" type="text" Value="1"> 
                        <button class="plus btn">+</button>
                     </div>
                  </div>
                  <div class="buy-product-btn py-2">
                     <ul class="list-unstyled d-xl-flex d-md-inline-block d-sm-flex align-items-center">
                        <button class="btn text-white btn-cart  buy_upsell_checkout5 me-3"  data-upsellId="<?php echo $_SESSION['upsellid']; ?>" data-upsell="<?php echo UPSELLID5; ?>"> ADD TEST KITS  </button>
                        <div class="buy_upsell_checkout5_responce"></div>
                        <li><a href="#" class="link-cstm-cs text-clr">No Additonal Test Kits Needed</a></li>
                     </ul>
                  </div>
                  <div class="about-this py-2">
                     <h5 class="pb-2 fw-600"> About this item </h5>
                     <ul class="ps-2 mb-0">
                        <li>Get results within 15 minutes</li>
                        <li>Suitable for everyone Aged 2 & above </li>
                        <li>Self Test from the comfort of your home/ Point of care solution </li>
                     </ul>
                  </div>
                  <div class="about-this py-2">
                     <h5 class="pb-2 fw-600"> Abbott BinaxNOW™ COVID-19 Home Test </h5>
                     <ul class="ps-2 mb-0">
                        <li>Abbott BinaxNOW™ COVID-19 Home Test is FDA Emergency Use Authorized. This Test combined with our Telehealth services, and partner lab's result, meets conditions of proof of negative COVID-19 Test by the CDC. </li>
                        <li>Your Test Kit includes a personal virtual visit with a Certified Guide who will help you properly administer the test and third party verify the result. You must provide your official Labs report or use ProvenPasss in order to board your flight or cruise. The report is provided the ProvenPass app, can be received via email and can be printed or displayed on screen to provide the needed proof. </li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <section class="video-section py-5">
      <div class="container">
         <div class="row">
            <div class="col-md-6">
               <div class="videa-iframe-col">
                  <iframe width="100%" height="400" src="https://www.youtube.com/embed/baQQfoX-JXo" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>
               </div>
            </div>
            <div class="col-md-6">
               <div class="about-this abbott ">
                  <h1 class="pb-2 fw-bold">BinaxNOW™ COVID-19 Antigen Self-Test </h1>
                  <p>A fast, proven and trusted COVID-19 antigen test that can be performed with a simple nasal swab in the comfort and convenience of your home.</p>
                  <ul class="pl-3">
                     <li> Get results in 15 minutes.</li>
                     <li>Detects multiple strains, including the Delta variant.</li>
                     <li>Your results in the ProvenPass app.</li>
                  </ul>
                  <p>Frequent testing, known as serial testing, may detect COVID-19 more quickly and reduce the spread of infection.Indicated for children as young as 2 years old when administered by an adult, and for all people 15 and older to self-administer.</p>
               </div>
            </div>
         </div>
      </div>
   </section>
   <section class="fullwidth-block py-5">
      <div class="container">
         <div class="row">
            <div class="col-md-12 text-center">
               <div class="inner-text">
                  <h1 class=" p-0 text-clr">
                     National Suppy Shortage.  Order enough Test Kits.
                  </h1>
               </div>
               <div class="buy-product-btn py-2 text-center mt-4">
                  <button type="button" class="btn last-btn text-uppercase blwaddtestkit text-white">Add Test Kits</button>
               </div>
            </div>
         </div>
      </div>
    </section>
    <script>
       function changeImage(element) {
           var main_prodcut_image = document.getElementById('main_product_image');
           main_prodcut_image.src = element.src;
       }
    </script>
</div>